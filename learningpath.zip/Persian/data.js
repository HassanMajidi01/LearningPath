const lessonsData = {
    "dars-1": {
        title: "آ ا",
        flashcardWords: [
            { word: 'بابا', image: 'assets/images/baba.webp', audio: 'assets/audio/baba.mp3', highlight: 'ا' },
            { word: 'آب', image: 'assets/images/ab.webp', audio: 'assets/audio/ab.mp3', highlight: 'آ' },
            { word: 'دَریا', image: 'assets/images/darya.webp', audio: 'assets/audio/darya.mp3', highlight: 'ا' },
            { word: 'آبی', image: 'assets/images/abi.webp', audio: 'assets/audio/abi.mp3', highlight: 'آ' },
            { word: 'آ', image: 'assets/images/a-aval.webp', audio: 'assets/audio/a-aval.mp3', highlight: 'آ' },
            { word: 'ا', image: 'assets/images/a-gheire-aval.webp', audio: 'assets/audio/a-gheire-aval.mp3', highlight: 'ا' },
            { word: 'باران', image: 'assets/images/baran.webp', audio: 'assets/audio/baran.mp3', highlight: 'ا' },
            { word: 'آرد', image: 'assets/images/ard.webp', audio: 'assets/audio/ard.mp3', highlight: 'آ' },
            { word: 'آذر', image: 'assets/images/azar.webp', audio: 'assets/audio/azar.mp3', highlight: 'آ' },
            { word: 'بادام', image: 'assets/images/badam.webp', audio: 'assets/audio/badam.mp3', highlight: 'ا' },
            { word: 'آسمان', image: 'assets/images/aseman.webp', audio: 'assets/audio/aseman.mp3', highlight: 'آ' },
            { word: 'باد', image: 'assets/images/bad.webp', audio: 'assets/audio/bad.mp3', highlight: 'ا' },
        ],
        // sentenceScramble: [
        //     { correct: "بابا آب داد", scrambled: ["داد", "بابا", "آب"] }
        // ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfmV8mEN3JqeJHy6-UZRMG4UGZcn8h9kn1sqscPoZJNyoecUw/viewform?usp=header",
         videos: [
            {
                title: "آموزش نشانه آ با داستان",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kcw3u62/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-2": {
        title: "ب",
        flashcardWords: [
            { word: 'آب', image: 'assets/images/ab.webp', audio: 'assets/audio/ab.mp3', highlight: 'ب' },
            { word: 'اَبر', image: 'assets/images/abr.webp', audio: 'assets/audio/abr.mp3', highlight: 'ب' },
            { word: 'سَبَد', image: 'assets/images/sabad.webp', audio: 'assets/audio/sabad.mp3', highlight: 'ب' },
            { word: 'اَسب', image: 'assets/images/asb.webp', audio: 'assets/audio/asb.mp3', highlight: 'ب' },
            { word: 'باد', image: 'assets/images/bad.webp', audio: 'assets/audio/bad.mp3', highlight: 'ب' },
            { word: 'بابا', image: 'assets/images/baba.webp', audio: 'assets/audio/baba.mp3', highlight: 'ب' },
            { word: 'آبی', image: 'assets/images/abi.webp', audio: 'assets/audio/abi.mp3', highlight: 'ب' },
            { word: 'باران', image: 'assets/images/baran.webp', audio: 'assets/audio/baran.mp3', highlight: 'ب' },
            { word: 'کتاب', image: 'assets/images/ketab.webp', audio: 'assets/audio/ketab.mp3', highlight: 'ب' },
            { word: 'تاب', image: 'assets/images/tab.webp', audio: 'assets/audio/tab.mp3', highlight: 'ب' },
            { word: 'سیب', image: 'assets/images/sib.webp', audio: 'assets/audio/sib.mp3', highlight: 'ب' }

        ],
        // sentenceScramble: [ ... ], // در صورت نیاز اضافه شود
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSd4KLK0wZDMAUE1y50sIEIV0HRVGNrWzumbZMp7oLQbBQz_iA/viewform?usp=header",
        videos: [
            {
                title: "داستان نشانه ب",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kgg90qt/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-3": {
        title: "اَ",
        flashcardWords: [
            { word: 'اَبر', image: 'assets/images/abr.webp', audio: 'assets/audio/abr.mp3', highlight: 'اَ' },
            { word: 'دَریا', image: 'assets/images/darya.webp', audio: 'assets/audio/darya.mp3', highlight: 'َ' },
            { word: 'بادبادَک', image: 'assets/images/badbadak.webp', audio: 'assets/audio/badbadak.mp3', highlight: 'َ' },
            { word: 'اَمین', image: 'assets/images/amin.webp', audio: 'assets/audio/amin.mp3', highlight: 'اَ' },
            { word: 'اَسب', image: 'assets/images/asb.webp', audio: 'assets/audio/asb.mp3', highlight: 'اَ' },
            { word: 'سَبَد', image: 'assets/images/sabad.webp', audio: 'assets/audio/sabad.mp3', highlight: 'َ' },
            { word: 'اَ', image: 'assets/images/@-aval.webp', audio: 'assets/audio/@-aval.mp3', highlight: 'اَ' },
            { word: '-َ', image: 'assets/images/@-gheire-aval.webp', audio: 'assets/audio/@-gheire-aval.mp3', highlight: 'َ' },
            { word: 'اَنار', image: 'assets/images/anar.webp', audio: 'assets/audio/anar.mp3', highlight: 'اَ' }
        ],
        // sentenceScramble: [ ... ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSefi0F8yNkjRG5dmpUjlQOoFvxiJMHML6uPL3M-qicrGVKDUQ/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه اَ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/ytwrxh0/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-4": {
        title: "د",
        flashcardWords: [
            { word: 'باد', image: 'assets/images/bad.webp', audio: 'assets/audio/bad.mp3', highlight: 'د' },
            { word: 'دَریا', image: 'assets/images/darya.webp', audio: 'assets/audio/darya.mp3', highlight: 'د' },
            { word: 'بادبادَک', image: 'assets/images/badbadak.webp', audio: 'assets/audio/badbadak.mp3', highlight: 'د' },
            { word: 'بااَدَب', image: 'assets/images/baadab.webp', audio: 'assets/audio/baadab.mp3', highlight: 'د' },
            { word: 'د', image: 'assets/images/d.webp', audio: 'assets/audio/d.mp3', highlight: 'د' },
            { word: 'دَر', image: 'assets/images/dar.webp', audio: 'assets/audio/dar.mp3', highlight: 'د' },
            { word: 'سَبَد', image: 'assets/images/sabad.webp', audio: 'assets/audio/sabad.mp3', highlight: 'د' },
            { word: 'مِداد', image: 'assets/images/medad.webp', audio: 'assets/audio/medad.mp3', highlight: 'د' }
        ],
        sentenceScramble: [ 
            { correct: "بابا آب داد", scrambled: ["داد", "بابا", "آب"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScmDpGr1sU_zy2UWiJUTNScaJKsOmekvbuesVuG4cX0L5lZ8w/viewform?usp=header",
        videos: [
            {
                title: "داستان نشانه د",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/wvxc3vw/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-5": {
        title: "م",
        flashcardWords: [
            { word: 'مِداد', image: 'assets/images/medad.webp', audio: 'assets/audio/medad.mp3', highlight: 'م' },
            { word: 'میز', image: 'assets/images/miz.webp', audio: 'assets/audio/miz.mp3', highlight: 'م' },
            { word: 'نیمکَت', image: 'assets/images/nimkat.webp', audio: 'assets/audio/nimkat.mp3', highlight: 'م' },
            { word: 'مَدرِسه', image: 'assets/images/madrese.webp', audio: 'assets/audio/madrese.mp3', highlight: 'م' },
            { word: 'مُدیر', image: 'assets/images/modir.webp', audio: 'assets/audio/modir.mp3', highlight: 'م' },
            { word: 'پَرچَم', image: 'assets/images/parcham.webp', audio: 'assets/audio/parcham.mp3', highlight: 'م' },
            { word: 'آدَم', image: 'assets/images/adam.webp', audio: 'assets/audio/adam.mp3', highlight: 'م' },
            { word: 'م', image: 'assets/images/m.webp', audio: 'assets/audio/m.mp3', highlight: 'م' },
			{ word: 'بادام', image: 'assets/images/badam.webp', audio: 'assets/audio/badam.mp3', highlight: 'م' },
			{ word: 'بَرادَرَم', image: 'assets/images/baradaram.webp', audio: 'assets/audio/baradaram.mp3', highlight: 'م' },
			{ word: 'دارَم', image: 'assets/images/daram.webp', audio: 'assets/audio/daram.mp3', highlight: 'م' },
			{ word: 'دَستَم', image: 'assets/images/dastam.webp', audio: 'assets/audio/dastam.mp3', highlight: 'م' },
			{ word: 'دوستَم', image: 'assets/images/doostam.webp', audio: 'assets/audio/doostam.mp3', highlight: 'م' },
			{ word: 'اِمام', image: 'assets/images/emam.webp', audio: 'assets/audio/emam.mp3', highlight: 'م' },
			{ word: 'مادَر', image: 'assets/images/madar.webp', audio: 'assets/audio/madar.mp3', highlight: 'م' },
			{ word: 'مار', image: 'assets/images/mar.webp', audio: 'assets/audio/mar.mp3', highlight: 'م' },
			{ word: 'مَسجِد', image: 'assets/images/masjed.webp', audio: 'assets/audio/masjed.mp3', highlight: 'م' },
			{ word: 'شام', image: 'assets/images/sham.webp', audio: 'assets/audio/sham.mp3', highlight: 'م' }
        ],
        sentenceScramble: [ 
            { correct: "باد آمَد", scrambled: ["آمَد", "باد"] },
            { correct: "بابا بادام داد", scrambled: ["داد", "بابا", "بادام"] },
            { correct: "بابا آمَد", scrambled: ["آمَد", "بابا"] },
            { correct: "بابا با داماد آمَد", scrambled: ["با", "بابا", "آمَد", "داماد"] },
            { correct: "آدَم آمَد", scrambled: ["آمَد", "آدَم"] },
            { correct: "داماد آب داد", scrambled: ["داد", "آب", "داماد"] },
            { correct: "دادا بادام داد", scrambled: ["داد", "بادام", "دادا"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSeI065rZYu5e0qrLUmWdD9VPKURkfns17BqGSg_Ep4UHVvGFA/viewform?usp=header",
        videos: [
            {
                title: "داستان نشانه م",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/hmh2880/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-6": {
        title: "س",
        flashcardWords: [
            { word: 'دَست', image: 'assets/images/dast.webp', audio: 'assets/audio/dast.mp3', highlight: 'س' },
            { word: 'سَبَد', image: 'assets/images/sabad.webp', audio: 'assets/audio/sabad.mp3', highlight: 'س' },
            { word: 'یاس', image: 'assets/images/yas.webp', audio: 'assets/audio/yas.mp3', highlight: 'س' },
            { word: 'کِلاس', image: 'assets/images/kelas.webp', audio: 'assets/audio/kelas.mp3', highlight: 'س' },
            { word: 'خِرس', image: 'assets/images/khers.webp', audio: 'assets/audio/khers.mp3', highlight: 'س' },
            { word: 'سِتاره', image: 'assets/images/setare.webp', audio: 'assets/audio/setare.mp3', highlight: 'س' },
            { word: 'س', image: 'assets/images/s.webp', audio: 'assets/audio/s.mp3', highlight: 'س' },
            { word: 'آسمان', image: 'assets/images/aseman.webp', audio: 'assets/audio/aseman.mp3', highlight: 'س' }
        ],
        sentenceScramble: [ 
            { correct: "بابا داس داد", scrambled: ["داد", "بابا", "داس"] },
            { correct: "بابا با اَسب آمد", scrambled: ["آمد", "بابا", "اَسب", "با"] },
            { correct: "سَبا با سام آمَد", scrambled: ["آمَد", "سَبا", "سام", "با"] },
            { correct: "سام با سَبَد آدامس داد", scrambled: ["آدامس", "سَبَد", "سام", "با", "داد"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSe4LmTAE8rZMBTVgvQ8csv_H0jO-AnZK9wKpOtMVU7VeOBE_A/viewform?usp=header",
        videos: [
            {
                title: "داستان نشانه س",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/xlg6g35/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-7": {
        title: "او و",
        flashcardWords: [
            { word: 'توت', image: 'assets/images/toot.webp', audio: 'assets/audio/toot.mp3', highlight: 'و' },
            { word: 'هُلو', image: 'assets/images/holoo.webp', audio: 'assets/audio/holoo.mp3', highlight: 'و' },
            { word: 'اَنگور', image: 'assets/images/angoor.webp', audio: 'assets/audio/angoor.mp3', highlight: 'و' },
            { word: 'آلو', image: 'assets/images/aloo.webp', audio: 'assets/audio/aloo.mp3', highlight: 'و' },
            { word: 'او', image: 'assets/images/oo-aval.webp', audio: 'assets/audio/oo-aval.mp3', highlight: 'او' },
            { word: 'دوست', image: 'assets/images/doost.webp', audio: 'assets/audio/doost.mp3', highlight: 'و' },
            { word: 'اوستا', image: 'assets/images/oosta.webp', audio: 'assets/audio/oosta.mp3', highlight: 'او' },
            { word: 'و', image: 'assets/images/v.webp', audio: 'assets/audio/oo-gheire-aval.mp3', highlight: 'و' }
        ],
        sentenceScramble: [ 
            { correct: "او با اَدَب بود", scrambled: ["او", "با", "اَدَب", "بود"] },
            { correct: "او داس داد", scrambled: ["داد", "او", "داس"] },
            { correct: "با بابا بودَم", scrambled: ["با", "بابا", "بودَم"] },
            { correct: "او با اَسب آمَد", scrambled: ["با", "او", "آمَد", "اَسب"] },
            { correct: "اَسَد با اَسب آمَد", scrambled: ["اَسَد", "با", "اَسب", "آمَد"] },
            { correct: "بابا با ما بود", scrambled: ["بابا", "با", "ما", "بود"] },
            { correct: "دود بَد بو بود", scrambled: ["دود", "بَد", "بو", "بود"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSeZnnVULNBWeQA4oVGALDaBYJl2TiUzxpCq25uu-Zp_8uoYzg/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی صدای او",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/rrt857a/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-8": {
        title: "ت",
        flashcardWords: [
            { word: 'تاب', image: 'assets/images/tab.webp', audio: 'assets/audio/tab.mp3', highlight: 'ت' },
            { word: 'توپ', image: 'assets/images/toop.webp', audio: 'assets/audio/toop.mp3', highlight: 'ت' },
            { word: 'سوت', image: 'assets/images/soot.webp', audio: 'assets/audio/soot.mp3', highlight: 'ت' },
            { word: 'دَست', image: 'assets/images/dast.webp', audio: 'assets/audio/dast.mp3', highlight: 'ت' },
            { word: 'تور', image: 'assets/images/toor.webp', audio: 'assets/audio/toor.mp3', highlight: 'ت' },
            { word: 'تَب', image: 'assets/images/t@b.webp', audio: 'assets/audio/t@b.mp3', highlight: 'ت' },
            { word: 'ت', image: 'assets/images/t.webp', audio: 'assets/audio/t.mp3', highlight: 'ت' },
            { word: 'تاس', image: 'assets/images/tas.webp', audio: 'assets/audio/tas.mp3', highlight: 'ت' }
        ],
        sentenceScramble: [ 
            { correct: "بابا تاب بَست", scrambled: ["تاب", "بابا", "بَست"] },
            { correct: "سام تاب بَست", scrambled: ["تاب", "سام", "بَست"] },
            { correct: "او با سام دوست اَست", scrambled: ["با", "او", "سام", "دوست", "اَست"] },
            { correct: "سام با سَبَد توت داد", scrambled: ["با", "سام", "سَبَد", "توت", "داد"] },
            { correct: "بابا با دَست تاب بَست", scrambled: ["با", "بابا", "دَست", "تاب", "بَست"] },
            { correct: "بابا با اَسَد دَست داد", scrambled: ["با", "بابا", "دَست", "اَسَد", "داد"] },
            { correct: "سام با اَسَد دوست اَست", scrambled: ["با", "سام", "دوست", "اَسَد", "اَست"] },
            { correct: "سام سوت داد", scrambled: ["سام", "سوت", "داد"] },
            { correct: "با سام دَست دادَم", scrambled: ["سام", "با", "دادَم", "دَست"] },
            { correct: "او با دوستَم آمَد", scrambled: ["او", "با", "دوستَم", "آمَد"] },
            { correct: "با دَستَم تاب بَستَم", scrambled: ["با", "دَستَم", "تاب", "بَستَم"] },
            { correct: "سَما با سَبَد توت داد", scrambled: ["با", "سَبَد", "سما", "توت", "داد"] },
            { correct: "سوت دَستَم بود", scrambled: ["دَستَم", "سوت", "بود"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdsCE74wjkbxEwy10_1P7SuRwb9EqkUk1ZKIwKDEfmtq63lHg/viewform?usp=header",
            videos: [
            {
                title: "داستان نشانه ت",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/jheu1l6/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-9": {
        title: "ر",
        flashcardWords: [
            { word: 'مادَر', image: 'assets/images/madar.webp', audio: 'assets/audio/madar.mp3', highlight: 'ر' },
            { word: 'اَبر', image: 'assets/images/abr.webp', audio: 'assets/audio/abr.mp3', highlight: 'ر' },
            { word: 'باران', image: 'assets/images/baran.webp', audio: 'assets/audio/baran.mp3', highlight: 'ر' },
            { word: 'مار', image: 'assets/images/mar.webp', audio: 'assets/audio/mar.mp3', highlight: 'ر' },
            { word: 'دَر', image: 'assets/images/dar.webp', audio: 'assets/audio/dar.mp3', highlight: 'ر' },
            { word: 'ر', image: 'assets/images/r.webp', audio: 'assets/audio/r.mp3', highlight: 'ر' },
            { word: 'رود', image: 'assets/images/roodkhane.webp', audio: 'assets/audio/rood.mp3', highlight: 'ر' },
            { word: 'سَر', image: 'assets/images/sar.webp', audio: 'assets/audio/sar.mp3', highlight: 'ر' }
        ],
        sentenceScramble: [ 
            { correct: "اَبر آمَد", scrambled: ["اَبر", "آمَد"] },
            { correct: "مادَر دَر دَست بادام دارَد", scrambled: ["مادَر", "دَر", "دَست", "بادام", "دارَد"] },
            { correct: "مادَرَم سَر دَرد دارَد", scrambled: ["مادَرَم", "سَر", "دَرد", "دارَد"] },
            { correct: "آرام آرام باران آمَد", scrambled: ["آمَد", "باران", "آرام", "آرام"] },
            { correct: "مادَر آرام آمَد", scrambled: ["آمَد", "مادَر", "آرام"] },
            { correct: "رامسَر روستا دارَد", scrambled: ["رامسَر", "روستا", "دارَد"] },
            { correct: "مار تَرس دارَد", scrambled: ["مار", "تَرس", "دارَد"] },
            { correct: "دارا دَرس دارَد", scrambled: ["دارا", "دَرس", "دارَد"] },
            { correct: "او دَر آستارا اَست", scrambled: ["او", "دَر", "آستارا", "اَست"] },
            { correct: "آدَم اَبرو دارَد", scrambled: ["آدَم", "اَبرو", "دارَد"] },
            { correct: "روستا آباد اَست", scrambled: ["روستا", "آباد", "اَست"] },
            { correct: "سارا با دَست تاب را بَست", scrambled: ["سارا", "با", "دَست", "تاب", "را", "بَست"] },
            { correct: "مادَر دَر دَست سَبَد دارَد", scrambled: ["دارَد", "سَبَد", "دَست", "دَر", "مادَر"] },
            { correct: "مادَر دَر باران آمد", scrambled: ["آمد", "باران", "دَر", "مادَر"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdb5Qnanos7ljL-kkfUPuEcQKPXuKX71zI-FbSSiCqnszL9wA/viewform?usp=header",
         videos: [
            {
                title: "لوحه خوانی نشانه ر",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/exvqbjd/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "نحوه حل تمرینات نگارش صفحه 51",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/qdim3me/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "مرور نشانه ها و صدا ها از آ تا د",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mhebznr/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "مرور نشانه ها از م تا ر",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/uhfnl18/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>'
            }
        ]
    },
    "dars-10": {
        title: "ن",
        flashcardWords: [
            { word: 'نانوا', image: 'assets/images/nanva.webp', audio: 'assets/audio/nanva.mp3', highlight: 'ن' },
            { word: 'نان', image: 'assets/images/nan.webp', audio: 'assets/audio/nan.mp3', highlight: 'ن' },
            { word: 'باران', image: 'assets/images/baran.webp', audio: 'assets/audio/baran.mp3', highlight: 'ن' },
            { word: 'اَمین', image: 'assets/images/amin.webp', audio: 'assets/audio/amin.mp3', highlight: 'ن' },
            { word: 'مامان', image: 'assets/images/madar.webp', audio: 'assets/audio/maman.mp3', highlight: 'ن' },
            { word: 'ن', image: 'assets/images/n.webp', audio: 'assets/audio/n.mp3', highlight: 'ن' },
            { word: 'ایران', image: 'assets/images/iran.webp', audio: 'assets/audio/iran.mp3', highlight: 'ن' },
            { word: 'آسمان', image: 'assets/images/aseman.webp', audio: 'assets/audio/aseman.mp3', highlight: 'ن' }
        ],
        sentenceScramble: [ 
            { correct: "باران نَم نَم آمَد", scrambled: ["آمَد", "نَم", "نَم", "باران"] },
            { correct: "مادَر دَر دَست نان دارَد", scrambled: ["دارَد","نان", "دَست", "دَر", "مادَر"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSem4pvz5RqmHwfFTUxN-_7g6jfM83KRetVUKgOWpuCIKoimVw/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ن",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/e074y2c/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-11": {
        title: "ای",
        flashcardWords: [
            { word: 'ایران', image: 'assets/images/iran.webp', audio: 'assets/audio/iran.mp3', highlight: 'ای' },
            { word: 'اَمین', image: 'assets/images/amin.webp', audio: 'assets/audio/amin.mp3', highlight: 'ی' },
            { word: 'ایرانی', image: 'assets/images/irani.webp', audio: 'assets/audio/irani.mp3', highlight: 'ی' },
            { word: 'آبی', image: 'assets/images/abi.webp', audio: 'assets/audio/abi.mp3', highlight: 'ی' },
            { word: 'سِفید', image: 'assets/images/sefid.webp', audio: 'assets/audio/sefid.mp3', highlight: 'ی' },
            { word: 'سُرمه ای', image: 'assets/images/sormeei.webp', audio: 'assets/audio/sormeei.mp3', highlight: 'ای' },
            { word: 'سیر', image: 'assets/images/sir.webp', audio: 'assets/audio/sir.mp3', highlight: 'ی' },
            { word: 'ای', image: 'assets/images/e.webp', audio: 'assets/audio/e.mp3', highlight: 'ای' },
            { word: 'سیب', image: 'assets/images/sib.webp', audio: 'assets/audio/sib.mp3', highlight: 'ی' }
        ],
        sentenceScramble: [ 
            { correct: "ایرانی بیدار اَست", scrambled: ["اَست","بیدار", "ایرانی"] },
            { correct: "من ایران را دوست دارَم", scrambled: ["دارَم","دوست", "را", "ایران", "من"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScbIMv4nOiYpwoKi1b8coNk9yrIIH8orxMC2X1u9H5_ylKfsg/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ای",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kwg8037/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: " داستان نشانه ای",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/jmh93y9/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-12": {
        title: "ز",
        flashcardWords: [
            { word: 'سَرباز', image: 'assets/images/sarbaz.webp', audio: 'assets/audio/sarbaz.mp3', highlight: 'ز' },
            { word: 'تیراَنداز', image: 'assets/images/tirandaz.webp', audio: 'assets/audio/tirandaz.mp3', highlight: 'ز' },
            { word: 'زَرد', image: 'assets/images/zard.webp', audio: 'assets/audio/zard.mp3', highlight: 'ز' },
            { word: 'سَبز', image: 'assets/images/sabz.webp', audio: 'assets/audio/sabz.mp3', highlight: 'ز' },
            { word: 'ز', image: 'assets/images/z.webp', audio: 'assets/audio/za.mp3', highlight: 'ز' },
            { word: 'زَنبور', image: 'assets/images/zanboor.webp', audio: 'assets/audio/zanboor.mp3', highlight: 'ز' },
            { word: 'سوزَن', image: 'assets/images/soozan.webp', audio: 'assets/audio/soozan.mp3', highlight: 'ز' },
            { word: 'بازار', image: 'assets/images/bazar.webp', audio: 'assets/audio/bazar.mp3', highlight: 'ز' }
        ],
        sentenceScramble: [ 
            { correct: "ایران سَرسَبز اَست", scrambled: ["اَست","سَرسَبز", "ایران"] },
            { correct: "بابا میز می سازَد", scrambled: ["بابا","میز", "می سازَد"] },
            { correct: "این سَرباز ایرانی اَست", scrambled: ["اَست","سَرباز", "این", "ایرانی"] },
            { correct: "آن سیب زیبا اَست", scrambled: ["اَست","زیبا", "آن", "سیب"] },
            { correct: "مادر با سوزَن دامَن می دوزَد", scrambled: ["مادر","با", "سوزَن", "دامَن", "می دوزَد"] },
            { correct: "ما آزادی را دوست داریم", scrambled: ["ما","آزادی", "را", "دوست", "داریم"] },
            { correct: "زَری اَنار را اَز زَمین بَر می دارَد", scrambled: ["زَری","اَنار", "را", "اَز", "زَمین", "بَر می دارَد"] },
            { correct: "ایران زیبا اَست", scrambled: ["اَست","زیبا", "ایران"] },
            { correct: "میز زَرد اَست", scrambled: ["اَست","میز", "زَرد"] },
            { correct: "زَنبور مَن را زَد", scrambled: ["زَد", "را", "زَنبور", "مَن"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSen1KmEA-F88Rb9TZ-V9ymuII6UcVSF3Y2Jd6jKqj7bKtHvgw/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ز",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/qthm7lz/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-13": {
        title: "اِ",
        flashcardWords: [
            { word: 'اِستَخر', image: 'assets/images/estakhr.webp', audio: 'assets/audio/estakhr.mp3', highlight: 'اِ' },
            { word: 'نَرده', image: 'assets/images/narde.webp', audio: 'assets/audio/narde.mp3', highlight: 'ه' },
            { word: 'خانه', image: 'assets/images/khane.webp', audio: 'assets/audio/khane.mp3', highlight: 'ه' },
            { word: 'دِرَخت', image: 'assets/images/derakht.webp', audio: 'assets/audio/derakht.mp3', highlight: 'ِ' },
            { word: 'اِ', image: 'assets/images/ee.webp', audio: 'assets/audio/ee.mp3', highlight: 'اِ' },
            { word: 'بیمارِستان', image: 'assets/images/bimarestan.webp', audio: 'assets/audio/bimarestan.mp3', highlight: 'اِ' },
            { word: 'مِداد', image: 'assets/images/medad.webp', audio: 'assets/audio/medad.mp3', highlight: 'ه' },
            { word: 'سه', image: 'assets/images/3.webp', audio: 'assets/audio/3.mp3', highlight: 'ه' },
            { word: 'اِمام', image: 'assets/images/emam.webp', audio: 'assets/audio/emam.mp3', highlight: 'اِ' },
            { word: 'ماسه', image: 'assets/images/mase.webp', audio: 'assets/audio/mase.mp3', highlight: 'ه' },
            { word: 'اِنسان', image: 'assets/images/ensan.webp', audio: 'assets/audio/ensan.mp3', highlight: 'اِ' },
            { word: 'موزه', image: 'assets/images/mooze.webp', audio: 'assets/audio/mooze.mp3', highlight: 'ه' },
            { word: 'بوسه', image: 'assets/images/boose.webp', audio: 'assets/audio/boose.mp3', highlight: 'ه' },
            { word: 'دَنده', image: 'assets/images/dande.webp', audio: 'assets/audio/dande.mp3', highlight: 'ه' },
            { word: 'ایستاده', image: 'assets/images/istade.webp', audio: 'assets/audio/istade.mp3', highlight: 'ه' },
            { word: 'دَسته', image: 'assets/images/daste.webp', audio: 'assets/audio/daste.mp3', highlight: 'ه' },
            { word: 'زِمِستان', image: 'assets/images/zemestan.webp', audio: 'assets/audio/zemestan.mp3', highlight: 'ِ' },
            { word: 'نامه', image: 'assets/images/name.webp', audio: 'assets/audio/name.mp3', highlight: 'ه' },
            { word: 'روزنامه', image: 'assets/images/roozname.webp', audio: 'assets/audio/roozname.mp3', highlight: 'ه' },
            { word: 'سِتاره', image: 'assets/images/setare.webp', audio: 'assets/audio/setare.mp3', highlight: 'ه' },
            { word: 'مَدرِسه', image: 'assets/images/madrese.webp', audio: 'assets/audio/madrese.mp3', highlight: 'ه' }
        ],
        sentenceScramble: [ 
            { correct: "اِمروز به مَدرِسه آمَدَم", scrambled: ["مَدرِسه","به", "اِمروز", "آمَدَم"] },
            { correct: "بابا اِداره اَست", scrambled: ["اَست", "اِداره", "بابا"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScjjxzu2ZT75DzlUxTEy91rvdtVB8KlS515eraUhzldCCC3cQ/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: آموزش نشانه اِ ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/loqs6v6/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: ای مستقل و -ِ ربط",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/aenu10k/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-14": {
        title: "ش",
        flashcardWords: [
            { word: 'چِشم', image: 'assets/images/cheshm.webp', audio: 'assets/audio/cheshm.mp3', highlight: 'ش' },
            { word: 'گوش', image: 'assets/images/goosh.webp', audio: 'assets/audio/goosh.mp3', highlight: 'ش' },
            { word: 'اَنگُشت', image: 'assets/images/angosht.webp', audio: 'assets/audio/angosht.mp3', highlight: 'ش' },
            { word: 'شانه', image: 'assets/images/shane.webp', audio: 'assets/audio/shane.mp3', highlight: 'ش' },
            { word: 'ش', image: 'assets/images/sh.webp', audio: 'assets/audio/sh.mp3', highlight: 'ش' },
            { word: 'شیر', image: 'assets/images/shir.webp', audio: 'assets/audio/shir.mp3', highlight: 'ش' },
            { word: 'شیرینی', image: 'assets/images/shirini.webp', audio: 'assets/audio/shirini.mp3', highlight: 'ش' },
            { word: 'شامی', image: 'assets/images/shami.webp', audio: 'assets/audio/shami.mp3', highlight: 'ش' }
        ],
        sentenceScramble: [ 
            { correct: "شیراز زیبا اَست", scrambled: ["اَست","زیبا", "شیراز"] },
            { correct: "اِمشَب شامی داریم", scrambled: ["داریم", "شامی", "اِمشَب"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScMlKtfqRthmMICS-vrtQ4YcvQFCwWth79X2vLoZ5AWSnsoQw/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/m7qb2eu/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-15": {
        title: "ی",
        flashcardWords: [
            { word: 'دَریا', image: 'assets/images/darya.webp', audio: 'assets/audio/darya.mp3', highlight: 'ی' },
            { word: 'قایِق', image: 'assets/images/ghayegh.webp', audio: 'assets/audio/ghayegh.mp3', highlight: 'ی' },
            { word: 'یِک', image: 'assets/images/yek.webp', audio: 'assets/audio/yek.mp3', highlight: 'ی' },
            { word: 'چای', image: 'assets/images/chay.webp', audio: 'assets/audio/chay.mp3', highlight: 'ی' },
            { word: 'ی', image: 'assets/images/y.webp', audio: 'assets/audio/y.mp3', highlight: 'ی' },
            { word: 'سایه', image: 'assets/images/saye.webp', audio: 'assets/audio/saye.mp3', highlight: 'ی' },
            { word: 'رایانه', image: 'assets/images/rayane.webp', audio: 'assets/audio/rayane.mp3', highlight: 'ی' },
            { word: 'یاس', image: 'assets/images/yas.webp', audio: 'assets/audio/yas.mp3', highlight: 'ی' },
            { word: 'مِیمون', image: 'assets/images/meymoon.webp', audio: 'assets/audio/meymoon.mp3', highlight: 'ی' }
        ],
        sentenceScramble: [ 
            { correct: "دَریا آرام اَست", scrambled: ["اَست","دَریا", "آرام"] },
            { correct: "مَن دَریایِ آبی را دوست دارَم", scrambled: ["آبی", "دَریایِ", "مَن", "را", "دوست", "دارَم"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdeNv_O0eLexVscFaCLnfJRlKDxF8uja9iq_NqnbZH5DxdTng/viewform?usp=header",
        videoEmbed: 'YOUR_EMBED_CODE'
    },
    "dars-16": {
        title: "اُ",
        flashcardWords: [
            { word: 'مادَر بُزُرگ', image: 'assets/images/madarbozorg.webp', audio: 'assets/audio/madarbozorg.mp3', highlight: 'ُ' },
            { word: 'اُتاق', image: 'assets/images/otagh.webp', audio: 'assets/audio/otagh.mp3', highlight: 'اُ' },
            { word: 'اُردَک', image: 'assets/images/ordak.webp', audio: 'assets/audio/ordak.mp3', highlight: 'اُ' },
            { word: 'شُتُر', image: 'assets/images/shotor.webp', audio: 'assets/audio/shotor.mp3', highlight: 'ُ' },
            { word: 'اُستاد', image: 'assets/images/ostad.webp', audio: 'assets/audio/ostad.mp3', highlight: 'اُ' },
            { word: 'سُم', image: 'assets/images/som.webp', audio: 'assets/audio/som.mp3', highlight: 'ُ' },
            { word: 'اُتو', image: 'assets/images/otoo.webp', audio: 'assets/audio/otoo.mp3', highlight: 'اُ' },
            { word: 'اُ', image: 'assets/images/o.webp', audio: 'assets/audio/o.mp3', highlight: 'اُ' }
        ],
        sentenceScramble: [ 
            { correct: "ماشین تُرمُز دارَد", scrambled: ["دارَد","تُرمُز", "ماشین"] },
            { correct: "مادَربُزُرگ مَن را بوسید", scrambled: ["بوسید", "را", "مَن", "مادَربُزُرگ"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfeSYdY4uMZakiBnGVHLnO4Xf4ykZeeBXj869EMCo6Fri7r_A/viewform?usp=header",
        videoEmbed: 'YOUR_EMBED_CODE'
    },
    "dars-17": {
        title: "ک",
        flashcardWords: [
            { word: 'کَبوتَر', image: 'assets/images/kabootar.webp', audio: 'assets/audio/kabootar.mp3', highlight: 'ک' },
            { word: 'اُردَک', image: 'assets/images/ordak.webp', audio: 'assets/audio/ordak.mp3', highlight: 'ک' },
            { word: 'گُنجِشک', image: 'assets/images/gonjeshk.webp', audio: 'assets/audio/gonjeshk.mp3', highlight: 'ک' },
            { word: 'لَک لَک', image: 'assets/images/laklak.webp', audio: 'assets/audio/laklak.mp3', highlight: 'ک' },
            { word: 'کَندو', image: 'assets/images/kandoo.webp', audio: 'assets/audio/kandoo.mp3', highlight: 'ک' },
            { word: 'کَبک', image: 'assets/images/kabk.webp', audio: 'assets/audio/kabk.mp3', highlight: 'ک' },
            { word: 'ک', image: 'assets/images/k.webp', audio: 'assets/audio/k.mp3', highlight: 'ک' },
            { word: 'کوسه', image: 'assets/images/koose.webp', audio: 'assets/audio/koose.mp3', highlight: 'ک' },
            { word: 'کوزه', image: 'assets/images/kooze.webp', audio: 'assets/audio/kooze.mp3', highlight: 'ک' },
            { word: 'کوبیده', image: 'assets/images/koobide.webp', audio: 'assets/audio/koobide.mp3', highlight: 'ک' },
            { word: 'کَباب', image: 'assets/images/kabab.webp', audio: 'assets/audio/kabab.mp3', highlight: 'ک' },
            { word: 'کودَک', image: 'assets/images/koodak.webp', audio: 'assets/audio/koodak.mp3', highlight: 'ک' }
        ],
        sentenceScramble: [ 
            { correct: "اُردَک شِنا می کُنَد", scrambled: ["می کُنَد","شِنا", "اُردَک"] },
            { correct: "زَنبور دَر کَندو اَست", scrambled: ["اَست", "کَندو", "دَر", "زَنبور"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSeuVM1ZZxK7ARo6AZWDXCtAFQbKKuFu7RJLdAbUmVvre19Ttw/viewform?usp=header",
        videoEmbed: 'YOUR_EMBED_CODE'
    },
    "dars-18": {
        title: "و",
        flashcardWords: [
            { word: 'داوَر', image: 'assets/images/davar.webp', audio: 'assets/audio/davar.mp3', highlight: 'و' },
            { word: 'وَرزِش کار', image: 'assets/images/varzeshkar.webp', audio: 'assets/audio/varzeshkar.mp3', highlight: 'و' },
            { word: 'سَوار کار', image: 'assets/images/savarkar.webp', audio: 'assets/audio/savarkar.mp3', highlight: 'و' },
            { word: 'دَوَنده', image: 'assets/images/davande.webp', audio: 'assets/audio/davande.mp3', highlight: 'و' },
            { word: 'وَزنه بردار', image: 'assets/images/vaznebardar.webp', audio: 'assets/audio/vaznebardar.mp3', highlight: 'و' },
            { word: 'و', image: 'assets/images/v.webp', audio: 'assets/audio/v.mp3', highlight: 'و' },
            { word: 'وَرزِش', image: 'assets/images/varzesh.webp', audio: 'assets/audio/varzesh.mp3', highlight: 'و' },
            { word: 'کِشاوَرز', image: 'assets/images/keshavarz.webp', audio: 'assets/audio/keshavarz.mp3', highlight: 'و' }
        ],
        sentenceScramble: [ 
            { correct: "مادَرَم زَنی تَوانا اَست", scrambled: ["تَوانا","زَنی", "مادَرَم", "اَست"] },
            { correct: "با وَرزِش کَردَن شاد می شَویم", scrambled: ["می شَویم", "شاد", "وَرزِش کَردَن", "با"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSe8UpY6WUw5BUdtdwFiInW0uaj_lHscxbtDMOr2YF3AOa_V_w/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: آموزش نشانه و",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/iev9ofk/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: لوحه خوانی نشانه و",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/hlooc95/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-19": {
        title: "پ",
        flashcardWords: [
            { word: 'پَر', image: 'assets/images/par.webp', audio: 'assets/audio/par.mp3', highlight: 'پ' },
            { word: 'پَرَستو', image: 'assets/images/parastoo.webp', audio: 'assets/audio/parastoo.mp3', highlight: 'پ' },
            { word: 'پَروانه', image: 'assets/images/parvane.webp', audio: 'assets/audio/parvane.mp3', highlight: 'پ' },
            { word: 'هَواپِیما', image: 'assets/images/havapeyma.webp', audio: 'assets/audio/havapeyma.mp3', highlight: 'پ' },
            { word: 'پا', image: 'assets/images/pa.webp', audio: 'assets/audio/pa.mp3', highlight: 'پ' },
            { word: 'توپ', image: 'assets/images/toop.webp', audio: 'assets/audio/toop.mp3', highlight: 'پ' },
            { word: 'پ', image: 'assets/images/p.webp', audio: 'assets/audio/p.mp3', highlight: 'پ' },
            { word: 'پَرَنده', image: 'assets/images/parande.webp', audio: 'assets/audio/parande.mp3', highlight: 'پ' },
            { word: 'پارک', image: 'assets/images/park.webp', audio: 'assets/audio/park.mp3', highlight: 'پ' },
            { word: 'پاندا', image: 'assets/images/panda.webp', audio: 'assets/audio/panda.mp3', highlight: 'پ' },
            { word: 'پَنکه', image: 'assets/images/panke.webp', audio: 'assets/audio/panke.mp3', highlight: 'پ' },
            { word: 'پِزِشک', image: 'assets/images/pezeshk.webp', audio: 'assets/audio/pezeshk.mp3', highlight: 'پ' },
            { word: 'آشپَز', image: 'assets/images/ashpaz.webp', audio: 'assets/audio/ashpaz.mp3', highlight: 'پ' },
            { word: 'پَرَستار', image: 'assets/images/parastar.webp', audio: 'assets/audio/parastar.mp3', highlight: 'پ' },
            { word: 'پارو', image: 'assets/images/paroo.webp', audio: 'assets/audio/paroo.mp3', highlight: 'پ' },
            { word: 'پُست', image: 'assets/images/post.webp', audio: 'assets/audio/post.mp3', highlight: 'پ' },
            { word: 'سوپ', image: 'assets/images/soop.webp', audio: 'assets/audio/soop.mp3', highlight: 'پ' },
        ],
        sentenceScramble: [ 
            { correct: "پَرَستو پَرواز می کُنَد", scrambled: ["می کُنَد", "پَرواز", "پَرَستو"] },
            { correct: "پِزِشک به مَن دارو داد", scrambled: ["دارو", "مَن", "به", "پِزِشک", "داد"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdwPX35xluk0I3eln-l5WaBd91k2SnwvpBFJLzFlA5TQBO8lg/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: آموزش نشانه پ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/pmmb9fc/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: لوحه خوانی نشانه پ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/anw5g8y/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-20": {
        title: "گ",
        flashcardWords: [
            { word: 'گُرگ', image: 'assets/images/gorg.webp', audio: 'assets/audio/gorg.mp3', highlight: 'گ' },
            { word: 'گَوَزن', image: 'assets/images/gavazn.webp', audio: 'assets/audio/gavazn.mp3', highlight: 'گ' },
            { word: 'جَنگَل', image: 'assets/images/jangal.webp', audio: 'assets/audio/jangal.mp3', highlight: 'گ' },
            { word: 'مادربزرگ', image: 'assets/images/madarbozorg.webp', audio: 'assets/audio/madarbozorg.mp3', highlight: 'گ' },
            { word: 'گوشی', image: 'assets/images/gooshi.webp', audio: 'assets/audio/gooshi.mp3', highlight: 'گ' },
            { word: 'گاو', image: 'assets/images/gav.webp', audio: 'assets/audio/gav.mp3', highlight: 'گ' },
            { word: 'گ', image: 'assets/images/g.webp', audio: 'assets/audio/g.mp3', highlight: 'گ' },
            { word: 'گَندُم', image: 'assets/images/gandom.webp', audio: 'assets/audio/gandom.mp3', highlight: 'گ' },
        ],
        sentenceScramble: [ 
            { correct: "گاو شیر دارَد", scrambled: ["دارَد", "شیر", "گاو"] },
            { correct: "گَوَزن اَز گُرگ می تَرسَد", scrambled: ["می تَرسَد", "گُرگ", "اَز", "گَوَزن"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSeofyspof17_ycR8O4meh82rblZm0ZHYLcNBBiGyiHwN5TqyQ/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: آموزش نشانه گ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/wyod612/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: لوحه خوانی نشانه گ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/npr4j3d/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-21": {
        title: "ف",
        flashcardWords: [
            { word: 'کیف', image: 'assets/images/kif.webp', audio: 'assets/audio/kif.mp3', highlight: 'ف' },
            { word: 'کَفش', image: 'assets/images/kafsh.webp', audio: 'assets/audio/kafsh.mp3', highlight: 'ف' },
            { word: 'بَرف', image: 'assets/images/barf.webp', audio: 'assets/audio/barf.mp3', highlight: 'ف' },
            { word: 'آدَم بَرفی', image: 'assets/images/adambarfi.webp', audio: 'assets/audio/adambarfi.mp3', highlight: 'ف' },
            { word: 'آفتابی', image: 'assets/images/aftabi.webp', audio: 'assets/audio/aftabi.mp3', highlight: 'ف' },
            { word: 'ف', image: 'assets/images/f.webp', audio: 'assets/audio/f.mp3', highlight: 'ف' },
            { word: 'سِفید', image: 'assets/images/sefid.webp', audio: 'assets/audio/sefid.mp3', highlight: 'ف' },
            { word: 'فیروزه ای', image: 'assets/images/firoozee.webp', audio: 'assets/audio/firoozee.mp3', highlight: 'ف' },
        ],
        sentenceScramble: [ 
            { correct: "آسمان آفتابی نیست", scrambled: ["آسمان", "آفتابی", "نیست"] },
            { correct: "فَرید کَفشِ وَرزِشی دارَد", scrambled: ["دارَد", "وَرزِشی", "کَفشِ", "فَرید"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfhz3XaH6oxqMuGy4TIx9uv5Gc7FRR4i-KEw4F-zKYD7Oc73w/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ف",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/fnd9fd9/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "آموزش نشانه ف با داستان ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/b8whc6m/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "روخوانی درس روز برفی",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mh22xb2/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-22": {
        title: "خ",
        flashcardWords: [
            { word: 'مَلَخ', image: 'assets/images/malakh.webp', audio: 'assets/audio/malakh.mp3', highlight: 'خ' },
            { word: 'خَرگوش', image: 'assets/images/khargoosh.webp', audio: 'assets/audio/khargoosh.mp3', highlight: 'خ' },
            { word: 'دِرَخت', image: 'assets/images/derakht.webp', audio: 'assets/audio/derakht.mp3', highlight: 'خ' },
            { word: 'شاخه', image: 'assets/images/shakhe.webp', audio: 'assets/audio/shakhe.mp3', highlight: 'خ' },
            { word: 'رودخانه', image: 'assets/images/roodkhane.webp', audio: 'assets/audio/roodkhane.mp3', highlight: 'خ' },
            { word: 'خ', image: 'assets/images/kh.webp', audio: 'assets/audio/kh.mp3', highlight: 'خ' },
            { word: 'خانه', image: 'assets/images/khane.webp', audio: 'assets/audio/khane.mp3', highlight: 'خ' },
            { word: 'خَنده', image: 'assets/images/khande.webp', audio: 'assets/audio/khande.mp3', highlight: 'خ' },
            { word: 'خِرس', image: 'assets/images/khers.webp', audio: 'assets/audio/khers.mp3', highlight: 'خ' },
            { word: 'خُروس', image: 'assets/images/khoroos.webp', audio: 'assets/audio/khoroos.mp3', highlight: 'خ' },
            { word: 'خَمیازه', image: 'assets/images/khamyaze.webp', audio: 'assets/audio/khamiaze.mp3', highlight: 'خ' },
        ],
        sentenceScramble: [ 
            { correct: "دِرَخت کِنارِ رودخانه اَست", scrambled: ["رودخانه", "کِنارِ", "دِرَخت", "اَست"] },
            { correct: "خانه ی خَرگوش زیرِ دِرَخت اَست", scrambled: ["دِرَخت", "زیرِ", "خَرگوش", "خانه ی", "اَست"] },
            { correct: "پَرَستو رویِ شاخه ی دِرَخت اَست", scrambled: ["دِرَخت", "رویِ", "پَرَستو", "شاخه ی", "اَست"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSclu8b6AN1eFFsgxcd6bhiR3yk-G0a5WWm7seq29SJAW4wjjA/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه خ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/lmhu45p/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-23": {
        title: "ق",
        flashcardWords: [
            { word: 'قاشُق', image: 'assets/images/ghashogh.webp', audio: 'assets/audio/ghashogh.mp3', highlight: 'ق' },
            { word: 'بُشقاب', image: 'assets/images/boshghab.webp', audio: 'assets/audio/boshghab.mp3', highlight: 'ق' },
            { word: 'چاقو', image: 'assets/images/chaghoo.webp', audio: 'assets/audio/chaghoo.mp3', highlight: 'ق' },
            { word: 'قوری', image: 'assets/images/ghoori.webp', audio: 'assets/audio/ghoori.mp3', highlight: 'ق' },
            { word: 'قَندان', image: 'assets/images/ghandan.webp', audio: 'assets/audio/ghandan.mp3', highlight: 'ق' },
            { word: 'قَند', image: 'assets/images/ghand.webp', audio: 'assets/audio/ghand.mp3', highlight: 'ق' },
            { word: 'ق', image: 'assets/images/gh.webp', audio: 'assets/audio/ghain.mp3', highlight: 'ق' },
            { word: 'اُتاق', image: 'assets/images/otagh.webp', audio: 'assets/audio/otagh.mp3', highlight: 'ق' },
            { word: 'قَفَس', image: 'assets/images/ghafas.webp', audio: 'assets/audio/ghafas.mp3', highlight: 'ق' },
            { word: 'قو', image: 'assets/images/ghoo.webp', audio: 'assets/audio/ghoo.mp3', highlight: 'ق' },
            { word: 'قَناری', image: 'assets/images/ghanari.webp', audio: 'assets/audio/ghanari.mp3', highlight: 'ق' }
        ],
        sentenceScramble: [ 
            { correct: "آزاده قَندان را پُر اَز قَند کَرد", scrambled: ["پُر", "را", "قَندان", "آزاده", "اَز", "قَند", "کَرد"] },
            { correct: "مادَر قاشُق و بُشقاب را می شویَد", scrambled: ["را", "بُشقاب", "و", "قاشُق", "مادَر", "می شویَد"] },
            { correct: "قاسِم قایِق سَوارانی را که دَر دَریا مُسابِقه می دادَند تَشویق می کَرد", scrambled: ["که", "را", "سَوارانی", "قایِق", "قاسِم", "دَریا", "مُسابِقه", "می دادَند", "تَشویق", "می کَرد", "دَر"] },
            { correct: "پِدَر قوری وَ اِستِکان را به اُتاق می بَرَد", scrambled: ["اُتاق", "به", "را", "اِستِکان", "و", "قوری", "پدَر", "می بَرَد"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfyq_16LfaT9n3dImT5e-0QRvUVxouW7LLdc3AFk9QwA321FQ/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ق",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/dzsgnou/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-24": {
        title: "ل",
        flashcardWords: [
            { word: 'لانه', image: 'assets/images/lane.webp', audio: 'assets/audio/lane.mp3', highlight: 'ل' },
            { word: 'بُلبُل', image: 'assets/images/bolbol.webp', audio: 'assets/audio/bolbol.mp3', highlight: 'ل' },
            { word: 'گُل', image: 'assets/images/gol.webp', audio: 'assets/audio/gol.mp3', highlight: 'ل' },
            { word: 'لَبخَند', image: 'assets/images/labkhand.webp', audio: 'assets/audio/labkhand.mp3', highlight: 'ل' },
            { word: 'گُلابی', image: 'assets/images/golabi.webp', audio: 'assets/audio/golabi.mp3', highlight: 'ل' },
            { word: 'ل', image: 'assets/images/l.webp', audio: 'assets/audio/l.mp3', highlight: 'ل' },
            { word: 'شَلیل', image: 'assets/images/shalil.webp', audio: 'assets/audio/shalil.mp3', highlight: 'ل' },
            { word: 'گیلاس', image: 'assets/images/gilas.webp', audio: 'assets/audio/gilas.mp3', highlight: 'ل' },
            { word: 'آلبالو', image: 'assets/images/albaloo.webp', audio: 'assets/audio/albaloo.mp3', highlight: 'ل' },
            { word: 'آلو', image: 'assets/images/aloo.webp', audio: 'assets/audio/aloo.mp3', highlight: 'ل' }
        ],
        sentenceScramble: [ 
            { correct: "گُل لَبخَند زد", scrambled: ["زد", "لَبخَند", "گُل"] },
            { correct: "بُلبُل سَلام کَرد", scrambled: ["کَرد", "سَلام", "بُلبُل"] },
            { correct: "بُلبُل کِنارِ گُل لانه ساخت", scrambled: ["لانه", "گُل", "کِنارِ", "بُلبُل", "ساخت"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScIRkM4KKMxDPBtF7urNAAIEC8uUDOKjeM8-SpENKUq9GGVdg/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ل",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/eefx6bu/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "داستان نشانه ل",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/gbu19d6/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-25": {
        title: "ج",
        flashcardWords: [
            { word: 'جوجه', image: 'assets/images/jooje.webp', audio: 'assets/audio/jooje.mp3', highlight: 'ج' },
            { word: 'گُنجِشک', image: 'assets/images/gonjeshk.webp', audio: 'assets/audio/gonjeshk.mp3', highlight: 'ج' },
            { word: 'نارِنج', image: 'assets/images/narenj.webp', audio: 'assets/audio/narenj.mp3', highlight: 'ج' },
            { word: 'بِرِنج', image: 'assets/images/berenj.webp', audio: 'assets/audio/berenj.mp3', highlight: 'ج' },
            { word: 'پَنج', image: 'assets/images/panj.webp', audio: 'assets/audio/panj.mp3', highlight: 'ج' },
            { word: 'کاج', image: 'assets/images/kaj.webp', audio: 'assets/audio/kaj.mp3', highlight: 'ج' },
            { word: 'ج', image: 'assets/images/j.webp', audio: 'assets/audio/j.mp3', highlight: 'ج' },
            { word: 'سَنجاب', image: 'assets/images/sanjab.webp', audio: 'assets/audio/sanjab.mp3', highlight: 'ج' },
            { word: 'جَنگَل', image: 'assets/images/jangal.webp', audio: 'assets/audio/jangal.mp3', highlight: 'ج' },
            { word: 'مَسجِد', image: 'assets/images/masjed.webp', audio: 'assets/audio/masjed.mp3', highlight: 'ج' }
        ],
        sentenceScramble: [ 
            { correct: "گُل لَبخَند زد", scrambled: ["زَد", "لَبخَند", "گُل"] },
            { correct: "این جا شالیزار اَست", scrambled: ["شالیزار", "جا", "این", "اَست"] },
            { correct: "مَردان و زَنان دَر شالیزار بِرِنج می کارَند", scrambled: ["شالیزار", "دَر", "زَنان", "و", "مَردان", "بِرِنج", "می کارَند"] },
            { correct: "زیرِ دِرَختِ نارِج سه جوجه و پَنج گُنجِشک بازی می کنند", scrambled: ["و", "جوجه", "سه", "نارِج", "دِرَختِ", "زیرِ", "می کنند", "پَنج", "گُنجِشک", "بازی"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfQxJqN8ki8qEqOijwMBMNNsRnA_m4TRWzkGzYKUJXIM0Sqpg/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی نشانه ج",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/wmph7b4/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-26": {
        title: "اُ استثنا",
        flashcardWords: [
            { word: 'خورشید', image: 'assets/images/khorshid.webp', audio: 'assets/audio/khorshid.mp3', highlight: 'و' },
            { word: 'دو', image: 'assets/images/do.webp', audio: 'assets/audio/do.mp3', highlight: 'و' },
            { word: 'نوک', image: 'assets/images/nok.webp', audio: 'assets/audio/nok.mp3', highlight: 'و' },
            { word: 'موج', image: 'assets/images/moj.webp', audio: 'assets/audio/moj.mp3', highlight: 'و' },
            { word: 'خودکار', image: 'assets/images/khodkar.webp', audio: 'assets/audio/khodkar.mp3', highlight: 'و' },
            { word: 'خوردَن', image: 'assets/images/khordan.webp', audio: 'assets/audio/khordan.mp3', highlight: 'و' },
            { word: 'موتور', image: 'assets/images/motor.webp', audio: 'assets/audio/motor.mp3', highlight: 'و' },
            { word: 'نوزاد', image: 'assets/images/nozad.webp', audio: 'assets/audio/nozad.mp3', highlight: 'و' }
        ],
        sentenceScramble: [ 
            { correct: "خُروس به زمین نوک زد و دانه را خورد", scrambled: ["نوک", "زمین", "به", "خُروس", "زد", "و", "دانه", "را", "خورد"] },
            { correct: "وقتی که خورشید زمین را روشن کرد امین برای خُروسِ خود دانه ریخت", scrambled: ["کرد", "روشن", "را", "زمین", "خورشید", "که", "وقتی", "امین", "برای", "خُروسِ", "خود", "دانه", "ریخت"] },
            { correct: "دو روز پیش پدربزرگ برای امین یک خُروسِ خوش آواز خرید", scrambled: ["آواز", "خوش", "خُروسِ", "یک", "امین", "برای", "پدربزرگ", "دو", "پیش", "روز", "خرید"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfeSYdY4uMZakiBnGVHLnO4Xf4ykZeeBXj869EMCo6Fri7r_A/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: آموزش اُ استثنا",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mncnf6g/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: اُ استثنا خواندن متن کتاب",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/bal1isg/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش سوم: حل تمرینات نگارش درس اُ استثنا",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/rje3jd2/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-27": {
        title: "ه",
        flashcardWords: [
            { word: 'ماهی', image: 'assets/images/mahi.webp', audio: 'assets/audio/mahi.mp3', highlight: 'ه' },
            { word: 'آهو', image: 'assets/images/ahoo.webp', audio: 'assets/audio/ahoo.mp3', highlight: 'ه' },
            { word: 'کوه', image: 'assets/images/kooh.webp', audio: 'assets/audio/kooh.mp3', highlight: 'ه' },
            { word: 'ماه', image: 'assets/images/mah.webp', audio: 'assets/audio/mah.mp3', highlight: 'ه' },
            { word: 'هواپیما', image: 'assets/images/havapeyma.webp', audio: 'assets/audio/havapeyma.mp3', highlight: 'ه' },
            { word: 'هلو', image: 'assets/images/holoo.webp', audio: 'assets/audio/holoo.mp3', highlight: 'ه' },
            { word: 'ه', image: 'assets/images/h.webp', audio: 'assets/audio/h.mp3', highlight: 'ه' },
            { word: 'مَهتاب', image: 'assets/images/mahtab.webp', audio: 'assets/audio/mahtab.mp3', highlight: 'ه' }
        ],
        sentenceScramble: [ 
            { correct: "امروز هوا برای بازی در پارک بِسیار مُناسِب است", scrambled: ["است", "مُناسِب", "بِسیار", "پارک", "در", "بازی", "برای", "هوا", "امروز"] },
            { correct: "ای خُدایِ مِهربان آسمان و ماه و سِتاره هایَت را دوست دارَم", scrambled: ["دوست", "را", "هایَت", "سِتاره", "و", "ماه", "و", "آسمان", "مِهربان", "خُدایِ", "ای", "دارَم"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdGEIUggjeTSiLyRXUXeq3OqzjJRrRkry2w3HcnJp6xsmXzPg/viewform?usp=header",
        videos: [
            {
                title: "بخش اول: شکل های مختلف نشانه ه",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/zbyb65g/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: حل تمرینات نگارش نشانه ه",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kus81u8/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    },
    "dars-28": {
        title: "چ",
        flashcardWords: [
            { word: 'چوپان', image: 'assets/images/choopan.webp', audio: 'assets/audio/choopan.mp3', highlight: 'چ' },
            { word: 'چَراگاه', image: 'assets/images/charagah.webp', audio: 'assets/audio/charagah.mp3', highlight: 'چ' },
            { word: 'قوچ', image: 'assets/images/ghooch.webp', audio: 'assets/audio/ghooch.mp3', highlight: 'چ' },
            { word: 'چِشمه', image: 'assets/images/cheshme.webp', audio: 'assets/audio/cheshme.mp3', highlight: 'چ' },
            { word: 'چادُر', image: 'assets/images/chador.webp', audio: 'assets/audio/chador.mp3', highlight: 'چ' },
            { word: 'قارچ', image: 'assets/images/gharch.webp', audio: 'assets/audio/gharch.mp3', highlight: 'چ' },
            { word: 'چ', image: 'assets/images/ch.webp', audio: 'assets/audio/ch.mp3', highlight: 'چ' },
            { word: 'مورچه', image: 'assets/images/moorche.webp', audio: 'assets/audio/moorche.mp3', highlight: 'چ' },
            { word: 'چاقو', image: 'assets/images/chaghoo.webp', audio: 'assets/audio/chaghoo.mp3', highlight: 'چ' }
        ],
        sentenceScramble: [ 
            { correct: "گوسفَندان در چَراگاه می چَرَند", scrambled: ["گوسفَندان", "در", "می چَرَند"] },
            { correct: "قوچ کنارِ چِشمه ایستاده است", scrambled: ["است", "چِشمه", "ایستاده", "کنارِ", "قوچ"] },
            { correct: "چوپان زیرِ درخت نِشَسته است", scrambled: ["است", "نِشَسته", "درخت", "زیرِ", "چوپان"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfGw0Na2eX3Ve0GAhbP5ksQvq6srZBJcIumGz7QrVpcMPj1Iw/viewform?usp=header",
        videos: [
            {
                title: "لوحه خوانی چ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/xng93qk/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-29": {
        title: "ژ",
        flashcardWords: [
            { word: 'ژاله', image: 'assets/images/jhale.webp', audio: 'assets/audio/jhale.mp3', highlight: 'ژ' },
            { word: 'مَنیژه', image: 'assets/images/manijhe.webp', audio: 'assets/audio/manijhe.mp3', highlight: 'ژ' },
            { word: 'گُلِ پَژمُرده', image: 'assets/images/golepajhmorde.webp', audio: 'assets/audio/golepajhmorde.mp3', highlight: 'ژ' },
            { word: 'ژِله', image: 'assets/images/jhele.webp', audio: 'assets/audio/jhele.mp3', highlight: 'ژ' },
            { word: 'شوفاژ', image: 'assets/images/shoofajh.webp', audio: 'assets/audio/shoofajh.mp3', highlight: 'ژ' },
            { word: 'گاراژ', image: 'assets/images/garajh.webp', audio: 'assets/audio/garajh.mp3', highlight: 'ژ' },
            { word: 'ژ', image: 'assets/images/jh.webp', audio: 'assets/audio/jh.mp3', highlight: 'ژ' },
            { word: 'ژیان', image: 'assets/images/jhian.webp', audio: 'assets/audio/jhian.mp3', highlight: 'ژ' },
            { word: 'پژمان', image: 'assets/images/pejhman.webp', audio: 'assets/audio/pejhman.mp3', highlight: 'ژ' },
            { word: 'ژینا', image: 'assets/images/jhina.webp', audio: 'assets/audio/jhina.mp3', highlight: 'ژ' },
            { word: 'بیژن', image: 'assets/images/bijhan.webp', audio: 'assets/audio/bijhan.mp3', highlight: 'ژ' },
            { word: 'پژو', image: 'assets/images/pejho.webp', audio: 'assets/audio/pejho.mp3', highlight: 'ژ' }
        ],
        sentenceScramble: [ 
            { correct: "گُل ها پَژمُرده بودَند", scrambled: ["بودَند", "پَژمُرده", "گُل ها"] },
            { correct: "ژاله و مَنیژه به گُل ها آب دادَند", scrambled: ["گُل ها", "به", "مَنیژه", "و", "ژاله", "آب", "دادَند"] },
            { correct: "پِژمان ژیانِ خود را به گاراژ بُرد", scrambled: ["به", "را", "خود", "ژیانِ", "پِژمان", "گاراژ", "بُرد"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfipHpejQJpYsGLUh3CMZmivDDpa8IEYfWToPjSWt4IdDwl4Q/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ژ با داستان",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/lklsw9a/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "لوحه خوانی ژ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/dafgq4q/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-30": {
        title: "خوا",
        flashcardWords: [
            { word: 'خواندَن', image: 'assets/images/khandan.webp', audio: 'assets/audio/khandan.mp3', highlight: 'خوا' },
            { word: 'خوابیدَن', image: 'assets/images/khabidan.webp', audio: 'assets/audio/khabidan.mp3', highlight: 'خوا' },
            { word: 'تختِ خواب', image: 'assets/images/takhtekhab.webp', audio: 'assets/audio/takhtekhab.mp3', highlight: 'خوا' },
            { word: 'خواهَر', image: 'assets/images/azade.webp', audio: 'assets/audio/khahar.mp3', highlight: 'خوا' },
            { word: 'خوا', image: 'assets/images/kha.webp', audio: 'assets/audio/kha.mp3', highlight: 'خوا' },
            { word: 'خواستِگاری', image: 'assets/images/khastegari.webp', audio: 'assets/audio/khastegari.mp3', highlight: 'خوا' },
            { word: 'اُستخوان', image: 'assets/images/ostekhan.webp', audio: 'assets/audio/ostekhan.mp3', highlight: 'خوا' },
            { word: 'خواننده', image: 'assets/images/khanande.webp', audio: 'assets/audio/khanande.mp3', highlight: 'خوا' }
        ],
        sentenceScramble: [ 
            { correct: "مَن خواهرِ خوبی دارَم", scrambled: ["دارَم", "خوبی", "خواهرِ", "مَن"] },
            { correct: "خواهرم آزاده قَبل از خواب برایِ مَن کِتاب می خوانَد", scrambled: ["خواهرم", "آزاده", "قَبل", "از", "خواب", "برایِ", "مَن", "کِتاب", "می خوانَد"] },
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScrPjW30ZvlNQEQAHny7sUPsDFxd1_V7_d04ppS07L8qx3V0g/viewform?usp=header",
         videos: [
            {
                title: "بخش اول: آموزش خوا استثنا با داستان",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mwzpt2u/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: روخوانی درس خوا",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/wcbt4n9/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش سوم: توضیح تمرینات نگارش درس خوا ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/vckg137/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-31": {
        title: "تشدید",
        flashcardWords: [
            { word: 'دکّان', image: 'assets/images/dokkan.webp', audio: 'assets/audio/dokkan.mp3', highlight: 'ّ' },
            { word: 'نجّار', image: 'assets/images/najjar.webp', audio: 'assets/audio/najjar.mp3', highlight: 'ّ' },
            { word: 'کفّاش', image: 'assets/images/kaffash.webp', audio: 'assets/audio/kaffash.mp3', highlight: 'ّ' },
            { word: 'قنّاد', image: 'assets/images/ghannad.webp', audio: 'assets/audio/ghannad.mp3', highlight: 'ّ' },
            { word: 'تشکّر', image: 'assets/images/tashakkor.webp', audio: 'assets/audio/tashakkor.mp3', highlight: 'ّ' },
            { word: 'ارّه', image: 'assets/images/arre.webp', audio: 'assets/audio/arre.mp3', highlight: 'ّ' },
            { word: 'بَنّا', image: 'assets/images/banna.webp', audio: 'assets/audio/banna.mp3', highlight: 'ّ' },
            { word: 'نَقّاش', image: 'assets/images/naghghash.webp', audio: 'assets/audio/naghghash.mp3', highlight: 'ّ' },
            { word: 'بَقّال', image: 'assets/images/baghghal.webp', audio: 'assets/audio/baghghal.mp3', highlight: 'ّ' }
        ],
        sentenceScramble: [ 
            { correct: "این جا نجّاری است", scrambled: ["است", "نجّاری", "این جا"] },
            { correct: "مادرم دکّان ها را به من نشان می داد", scrambled: ["می داد", "نشان", "من", "به", "را", "دکّان ها", "مادرم"] },
            { correct: "پدرم از قنّادی شیرینی خرید", scrambled: ["پدرم", "از", "قنّادی", "شیرینی", "خرید"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScRmpKgwqu-ZDWJ4sBTzxbET3cCkNzqacjE1XqcBOKnq_5R-A/viewform?usp=header",
         videos: [
            {
                title: "آموزش تشدید",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/ntbxn2l/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "روخوانی درس در بازار",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/lipz5mi/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "سوالات درک مطلب درس در بازار",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kuukoq3/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "توضیح تمرینات صفحه 103 نگارش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mcy1879/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "توضیح تمرینات صفحه 104 نگارش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/mnk2z19/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "توضیح تمرینات صفحه 105 نگارش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/uwm0wpw/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
            
        ]
    },
    "dars-32": {
        title: "ص",
        flashcardWords: [
            { word: 'صدا', image: 'assets/images/seda.webp', audio: 'assets/audio/seda.mp3', highlight: 'ص' },
            { word: 'صف', image: 'assets/images/saf.webp', audio: 'assets/audio/saf.mp3', highlight: 'ص' },
            { word: 'صدف', image: 'assets/images/sadaf.webp', audio: 'assets/audio/sadaf.mp3', highlight: 'ص' },
            { word: 'ص', image: 'assets/images/sad.webp', audio: 'assets/audio/s.mp3', highlight: 'ص' },
            { word: 'قاصدک', image: 'assets/images/ghasedak.webp', audio: 'assets/audio/ghasedak.mp3', highlight: 'ص' },
            { word: 'صابون', image: 'assets/images/saboon.webp', audio: 'assets/audio/saboon.mp3', highlight: 'ص' },
            { word: 'صندوق', image: 'assets/images/sandogh.webp', audio: 'assets/audio/sandogh.mp3', highlight: 'ص' },
            { word: 'فصل', image: 'assets/images/fasl.webp', audio: 'assets/audio/fasl.mp3', highlight: 'ص' }
        ],
        sentenceScramble: [ 
            { correct: "صدایِ موج را شنیدم", scrambled: ["را", "موج", "صدایِ", "شنیدم"] },
            { correct: "صدف هایِ سفیدی در کنارِ دریا دیدم", scrambled: ["صدف هایِ", "سفیدی", "در", "کنارِ", "دریا", "دیدم"] },
            { correct: "آسمانِ صاف و آبیِ دریا خیلی دیدنی است", scrambled: ["آسمانِ", "صاف", "و", "آبیِ", "دریا", "خیلی", "دیدنی", "است"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLScKgEs_YZ1pUXRGKOLtQrSH8Tz67P6eYNpLxGSxvWuqTC4OWg/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ص",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/tgx71y8/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "روخوانی درس صدای موج",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/hww4h84/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
			{
                title: "توضیح نحوه حل صفحه 106 نگارش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/agghol1/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
            
        ]
    },
    "dars-33": {
        title: "ذ",
        flashcardWords: [
            { word: 'دلپذیر', image: 'assets/images/delpazir.webp', audio: 'assets/audio/delpazir.mp3', highlight: 'ذ' },
            { word: 'آذر', image: 'assets/images/azar.webp', audio: 'assets/audio/azar.mp3', highlight: 'ذ' },
            { word: 'لذّت', image: 'assets/images/lezzat.webp', audio: 'assets/audio/lezzat.mp3', highlight: 'ذ' },
            { word: 'ذ', image: 'assets/images/zal.webp', audio: 'assets/audio/za.mp3', highlight: 'ذ' },
            { word: 'ذُرّت', image: 'assets/images/zorrat.webp', audio: 'assets/audio/zorrat.mp3', highlight: 'ذ' },
            { word: 'ذَرّه بین', image: 'assets/images/zarrebin.webp', audio: 'assets/audio/zarrebin.mp3', highlight: 'ذ' },
            { word: 'لَذیذ', image: 'assets/images/laziz.webp', audio: 'assets/audio/laziz.mp3', highlight: 'ذ' },
            { word: 'اَذان', image: 'assets/images/azan.webp', audio: 'assets/audio/azan.mp3', highlight: 'ذ' }
        ],
        sentenceScramble: [ 
            { correct: "آذر دست بلند کرد", scrambled: ["بلند", "دست", "آذر", "کرد"] },
            { correct: "ژاله و مَنیژه به گُل ها آب دادَند", scrambled: ["گُل ها", "به", "مَنیژه", "و", "ژاله", "آب", "دادَند"] },
            { correct: "از دیدنِ شالیزار ها لذّت بردیم", scrambled: ["از", "دیدنِ", "شالیزار ها", "بردیم", "لذّت"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfuj0X5hlAL3ls_L52EjxiGcLC7rJBYxhG1_TJA-EaTs3Hg5A/viewform?usp=header",
        videos: [
            {
                title: "روخوانی درس سفر دلپذیر",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/zrcbix5/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    },
    "dars-34": {
        title: "ع",
        flashcardWords: [
            { word: 'علی', image: 'assets/images/ali.webp', audio: 'assets/audio/ali.mp3', highlight: 'ع' },
            { word: 'معصومه', image: 'assets/images/masoome.webp', audio: 'assets/audio/masoome.mp3', highlight: 'ع' },
            { word: 'مُعَلِّم', image: 'assets/images/moallem.webp', audio: 'assets/audio/moallem.mp3', highlight: 'ع' },
            { word: 'جَمع', image: 'assets/images/jame.webp', audio: 'assets/audio/jame.mp3', highlight: 'ع' },
            { word: 'عَصا', image: 'assets/images/asa.webp', audio: 'assets/audio/asa.mp3', highlight: 'ع' },
            { word: 'ساعت', image: 'assets/images/saat.webp', audio: 'assets/audio/saat.mp3', highlight: 'ع' },
            { word: 'عَروسَک', image: 'assets/images/aroosak.webp', audio: 'assets/audio/aroosak.mp3', highlight: 'ع' },
            { word: 'عِینَک', image: 'assets/images/einak.webp', audio: 'assets/audio/einak.mp3', highlight: 'ع' },
            { word: 'ع', image: 'assets/images/ain.webp', audio: 'assets/audio/ain.mp3', highlight: 'ع' }
        ],
        sentenceScramble: [ 
            { correct: "آن ها وسایلِ خود را جمع می کنند", scrambled: ["خود", "وسایلِ", "آن ها", "را", "جمع", "می کنند"] },
            { correct: "علی و معصومه بچه های با ادب و پاکیزه ای هستند", scrambled: ["پاکیزه ای", "و", "ادب", "با", "بچه های", "و", "علی", "هستند"] },
            { correct: "مادربزرگ برای خواندن کتاب عینک می زند", scrambled: ["مادربزرگ", "برای", "خواندن", "کتاب", "عینک", "می زند"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSe4kF3wvY7WfjwoJR5wpoeKnp1ynORq8IUc_2Ju5WpitGGC4g/viewform?usp=header",
         videos: [
            {
                title: "بخش اول: شکل های مختلف نشانه ع",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/uks7219/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش دوم: داستان نشانه های ذ، ص، ع",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/kojw79b/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "بخش سوم: لوحه خوانی نشانه ع",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/poyma3f/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
        
    },
    "dars-35": {
        title: "ث",
        flashcardWords: [
            { word: 'ث', image: 'assets/images/s....webp', audio: 'assets/audio/s.mp3', highlight: 'ث' },
            { word: 'ثُریّا', image: 'assets/images/soryya.webp', audio: 'assets/audio/soraya.mp3', highlight: 'ث' },
            { word: 'ثانیه', image: 'assets/images/sanye.webp', audio: 'assets/audio/saniye.mp3', highlight: 'ث' },
            { word: 'لَثه', image: 'assets/images/lase.webp', audio: 'assets/audio/lase.mp3', highlight: 'ث' },
            { word: 'مَبعَث', image: 'assets/images/mabas.webp', audio: 'assets/audio/mabas.mp3', highlight: 'ث' },
            { word: 'ثِروَت', image: 'assets/images/servat.webp', audio: 'assets/audio/servat.mp3', highlight: 'ث' },
            { word: 'کَثیف', image: 'assets/images/kasif.webp', audio: 'assets/audio/kasif.mp3', highlight: 'ث' },
            { word: 'مُثلَّث', image: 'assets/images/mosallas.webp', audio: 'assets/audio/mosalas.mp3', highlight: 'ث' },
        ],
        sentenceScramble: [ 
            { correct: "من چند ثانیه فکر کردم", scrambled: ["فکر", "چند", "من", "ثانیه", "کردم"] },
            { correct: "خورشید باعثِ روشن شدنِ زمین می شود", scrambled: ["می شود", "خورشید", "باعثِ", "روشن", "شدنِ", "زمین"] },
            { correct: "روزی که پیامبر مسلمانان به پیامبری برگزیده شد مبعث نام دارد", scrambled: ["روزی", "که", "پیامبر", "مسلمانان", "به", "پیامبری", "برگزیده", "شد", "مبعث", "نام", "دارد"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSeJOmQowa7EK7SFs1Q7CJUOOR7qCaXt-k3feyzVvSgXBFlg_g/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ث",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/oki6q3b/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "حل تمرینات صفحات 116 و 117 نگارش",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/wgcxs2e/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
        ]
    },
    "dars-36": {
        title: "ح",
        flashcardWords: [
            { word: 'حَلَزون', image: 'assets/images/halazoon.webp', audio: 'assets/audio/halazon.mp3', highlight: 'ح' },
            { word: 'خوش حال', image: 'assets/images/khoshhal.webp', audio: 'assets/audio/khoshhal.mp3', highlight: 'ح' },
            { word: 'صُبح', image: 'assets/images/sobh.webp', audio: 'assets/audio/sobh.mp3', highlight: 'ح' },
            { word: 'صُحبَت', image: 'assets/images/sohbat.webp', audio: 'assets/audio/sohbat.mp3', highlight: 'ح' },
            { word: 'حیوان', image: 'assets/images/heivan.webp', audio: 'assets/audio/heyvan.mp3', highlight: 'ح' },
            { word: 'حوله', image: 'assets/images/hole.webp', audio: 'assets/audio/hole.mp3', highlight: 'ح' },
            { word: 'ح', image: 'assets/images/hj.webp', audio: 'assets/audio/h.mp3', highlight: 'ح' },
            { word: 'حَمّام', image: 'assets/images/hammam.webp', audio: 'assets/audio/hammam.mp3', highlight: 'ح' }
        ],
        sentenceScramble: [ 
            { correct: "حَلَزون ها بدنی نرم دارند", scrambled: ["نرم", "بدنی", "حَلَزون ها", "دارند"] },
            { correct: "حَلَزون خیلی آرام حَرِکَت می کند", scrambled: ["حَلَزون", "خیلی", "آرام", "حَرِکَت", "می کند"] },
            { correct: "من امروز صُبح اِحساس خوبی داشتَم", scrambled: ["من", "امروز", "صُبح", "اِحساس", "خوبی", "داشتَم"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSd6HhbK1LNt8Apf-t4gFDTPGrf7X9athN7PRU5cFiTDnOrw_A/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ح",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/iske61f/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    },
    "dars-37": {
        title: "ض",
        flashcardWords: [
            { word: 'حوض', image: 'assets/images/hoz.webp', audio: 'assets/audio/hoz.mp3', highlight: 'ض' },
            { word: 'وُضو', image: 'assets/images/vozoo.webp', audio: 'assets/audio/vozoo.mp3', highlight: 'ض' },
            { word: 'مَریض', image: 'assets/images/t@b.webp', audio: 'assets/audio/mariz.mp3', highlight: 'ض' },
            { word: 'ض', image: 'assets/images/zad.webp', audio: 'assets/audio/za.mp3', highlight: 'ض' },
            { word: 'ریاضی', image: 'assets/images/math.webp', audio: 'assets/audio/riazi.mp3', highlight: 'ض' },
            { word: 'فضانَوَرد', image: 'assets/images/fazanavard.webp', audio: 'assets/audio/fazanavard.mp3', highlight: 'ض' },
            { word: 'رَمِضان', image: 'assets/images/ramezan.webp', audio: 'assets/audio/ramezan.mp3', highlight: 'ض' },
            { word: 'ضبط', image: 'assets/images/zabt.webp', audio: 'assets/audio/zabt.mp3', highlight: 'ض' }
        ],
        sentenceScramble: [ 
            { correct: "کنارِ حوض وُضو گِرِفتَم", scrambled: ["وُضو", "حوض", "کنارِ", "گِرِفتَم"] },
            { correct: "دوستم رضا در مسجد نبود", scrambled: ["دوستم", "رضا", "در", "مسجد", "نبود"] },
            { correct: "رضا مَریض است", scrambled: ["رضا", "مَریض", "است"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfjBilK2S1amh09l8qZCpxHNYq-aC4zoDSKArUQD4XCTQuFxg/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ض",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/dwdd81v/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    },
    "dars-38": {
        title: "ط",
        flashcardWords: [
            { word: 'حیاط', image: 'assets/images/hayat.webp', audio: 'assets/audio/hayat.mp3', highlight: 'ط' },
            { word: 'سَطل', image: 'assets/images/satl.webp', audio: 'assets/audio/satl.mp3', highlight: 'ط' },
            { word: 'وطن', image: 'assets/images/iran.webp', audio: 'assets/audio/vatan.mp3', highlight: 'ط' },
            { word: 'ط', image: 'assets/images/ta.webp', audio: 'assets/audio/t.mp3', highlight: 'ط' },
            { word: 'طاووس', image: 'assets/images/tavoos.webp', audio: 'assets/audio/tavoos.mp3', highlight: 'ط' },
            { word: 'مُستَطیل', image: 'assets/images/mostatil.webp', audio: 'assets/audio/mostatil.mp3', highlight: 'ط' },
            { word: 'طوطی', image: 'assets/images/tooti.webp', audio: 'assets/audio/tooti.mp3', highlight: 'ط' },
            { word: 'قطار', image: 'assets/images/ghatar.webp', audio: 'assets/audio/ghatar.mp3', highlight: 'ط' },
            { word: 'طناب', image: 'assets/images/tanab.webp', audio: 'assets/audio/tanab.mp3', highlight: 'ط' }
        ],
        sentenceScramble: [ 
            { correct: "ما در حیاط صف بسته بودیم", scrambled: ["ما", "در", "حیاط", "صف", "بسته", "بودیم"] },
            { correct: "مُدیر خاطراتِ روز های انقلاب را تعریف می کرد", scrambled: ["روز های", "انقلاب", "را", "تعریف", "می کرد", "خاطراتِ", "مُدیر"] },
            { correct: "صدای سوت قطار به گوش می رِسَد", scrambled: ["به", "گوش", "می رِسَد", "صدای", "سوت", "قطار"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdzDpaseAuIAs04nPGduU2fGJtUL0DZha-jVpXy95r6tTmGOA/viewform?usp=header",
        videoEmbed: 'YOUR_EMBED_CODE'
    },
    "dars-39": {
        title: "غ",
        flashcardWords: [
            { word: 'مرغابی', image: 'assets/images/morghabi.webp', audio: 'assets/audio/morghabi.mp3', highlight: 'غ' },
            { word: 'غمگین', image: 'assets/images/ghamgin.webp', audio: 'assets/audio/ghamgin.mp3', highlight: 'غ' },
            { word: 'کلاغ', image: 'assets/images/kalagh.webp', audio: 'assets/audio/kalagh.mp3', highlight: 'غ' },
            { word: 'غ', image: 'assets/images/ghain.webp', audio: 'assets/audio/ghain.mp3', highlight: 'غ' },
            { word: 'جیغ', image: 'assets/images/jigh.webp', audio: 'assets/audio/jigh.mp3', highlight: 'غ' },
            { word: 'تیغ', image: 'assets/images/tigh.webp', audio: 'assets/audio/tigh.mp3', highlight: 'غ' },
            { word: 'قورباغه', image: 'assets/images/ghoorbaghe.webp', audio: 'assets/audio/ghoorbaghe.mp3', highlight: 'غ' },
            { word: 'غاز', image: 'assets/images/ghaz.webp', audio: 'assets/audio/ghaz.mp3', highlight: 'غ' },
            { word: 'مرغ', image: 'assets/images/morgh.webp', audio: 'assets/audio/morgh.mp3', highlight: 'غ' },
            { word: 'جغد', image: 'assets/images/joghd.webp', audio: 'assets/audio/joghd.mp3', highlight: 'غ' }
        ],
        sentenceScramble: [ 
            { correct: "لاک پشت غمگین شد", scrambled: ["شد", "غمگین", "لاک پشت"] },
            { correct: "مرغابی ها مجبور شدند از آن جا بروند", scrambled: ["مرغابی ها", "مجبور", "شدند", "از", "آن", "جا", "بروند"] },
            { correct: "کلاغ و جغد دو مرغابی را دیدند", scrambled: ["کلاغ", "و", "جغد", "دو", "مرغابی", "را", "دیدند"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSfFJDc_9feY6Q3twYnRirk0f7fwXeYSaZjjnCZAyEIepU_mzg/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه غ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/ryv5mo6/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            },
            {
                title: "درس ۲۱ فارسی لاکپشت و مرغابی ها",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/nos3nas/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    },
    "dars-40": {
        title: "ظ",
        flashcardWords: [
            { word: 'ظُلم', image: 'assets/images/zolm.webp', audio: 'assets/audio/zolm.mp3', highlight: 'ظ' },
            { word: 'حافظ', image: 'assets/images/hafez.webp', audio: 'assets/audio/hafez.mp3', highlight: 'ظ' },
            { word: 'ناظم مدرسه', image: 'assets/images/nazememadrese.webp', audio: 'assets/audio/nazememadrese.mp3', highlight: 'ظ' },
            { word: 'ظ', image: 'assets/images/za.webp', audio: 'assets/audio/za.mp3', highlight: 'ظ' },
            { word: 'پیامبر اعظم', image: 'assets/images/mabas.webp', audio: 'assets/audio/payambareaazam.mp3', highlight: 'ظ' },
            { word: 'نظامی', image: 'assets/images/nezami.webp', audio: 'assets/audio/nezami.mp3', highlight: 'ظ' },
            { word: 'ظُهر', image: 'assets/images/aftabi.webp', audio: 'assets/audio/zohr.mp3', highlight: 'ظ' },
            { word: 'مُحافِظَت', image: 'assets/images/mohafezat.webp', audio: 'assets/audio/mohafezat.mp3', highlight: 'ظ' }
        ],
        sentenceScramble: [ 
            { correct: "پیامبر اعظم از همان کودکی بسیار مهربان بود", scrambled: ["پیامبر", "اعظم", "از", "همان", "کودکی", "بسیار","مهربان", "بود"] },
            { correct: "او هرگز در برابر ظلم آرام نمی نشست", scrambled: ["او", "هرگز", "در", "برابر", "ظلم", "آرام", "نمی نشست"] }
         ],
        quizLink: "https://docs.google.com/forms/d/e/1FAIpQLSdyd2RP-RjJQBYIv5F_-5BvgsoXr3l6vd81vmY-TEMSlzi5fQ/viewform?usp=header",
        videos: [
            {
                title: "آموزش نشانه ظ",
                embedCode: '<iframe src="https://www.aparat.com/video/video/embed/videohash/souwa83/vt/frame"  allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'
            }
            
        ]
    }
};